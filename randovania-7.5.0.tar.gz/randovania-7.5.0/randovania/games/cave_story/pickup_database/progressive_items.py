from __future__ import annotations


def tuples():
    return [
        ("Progressive Polar Star", ("Polar Star", "Spur")),
        ("Progressive Booster", ("Booster 0.8", "Booster 2.0")),
        ("Progressive Missile Launcher", ("Missile Launcher", "Super Missile Launcher")),
    ]
