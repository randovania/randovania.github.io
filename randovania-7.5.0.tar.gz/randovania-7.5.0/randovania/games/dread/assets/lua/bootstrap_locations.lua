for n,i in pairs{TEMPLATE("pairs")}do RL.Pickups[i]=RandomizerPowerup.PropertyForLocation(TEMPLATE("location")..n) end
