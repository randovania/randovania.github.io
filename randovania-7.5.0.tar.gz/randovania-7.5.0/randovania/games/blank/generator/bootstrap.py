from __future__ import annotations

from randovania.resolver.bootstrap import Bootstrap


class BlankBootstrap(Bootstrap):
    pass
