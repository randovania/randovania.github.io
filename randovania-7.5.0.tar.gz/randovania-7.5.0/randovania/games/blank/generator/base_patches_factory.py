from __future__ import annotations

from randovania.generator.base_patches_factory import BasePatchesFactory


class BlankBasePatchesFactory(BasePatchesFactory):
    pass
